# Cleaning Robots Control System

This project implements a control and monitoring system for a fleet of autonomous cleaning robots.

## Build & Run
```bash
make
./cleaning_system
```

Developed by Yuval Notkin

