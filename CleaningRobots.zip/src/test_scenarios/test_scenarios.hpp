#pragma once

int run_all_scenarios();
int run_single_scenario();